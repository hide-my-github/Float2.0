﻿using System;
using Priority_Queue;

namespace Priority_Queue_Example
{
    class Program
    {


        static void Main(string[] args)
        {
            FastPriorityQueueExample.RunExample();

            Console.WriteLine("------------------------------");

            SimplePriorityQueueExample.RunExample();

            Console.ReadKey();
        }
    }
}
